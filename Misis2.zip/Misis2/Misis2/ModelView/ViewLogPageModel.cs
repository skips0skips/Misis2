﻿using Misis2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Misis2.ModelView
{
    public class ViewLogPageModel : INotifyPropertyChanged
    {

        public ViewLogPageModel()
        {
            DisciplineList = GetDiscipline().OrderBy(t => t.Name).ToList();
            MyDiscipline = "Выбранно : ";
            TimeFullList = GetTimeFull().OrderBy(t => t.groupName).ToList();
            MyTimeFull = "Выбранно : ";

            StartDate = new DateTime(2020, 1, 1);
            EndDate = new DateTime(2020, 3, 31);
        }
        private string _myDiscipline;
        public string MyDiscipline
        {
            get { return _myDiscipline; }
            set
            {
                if (_myDiscipline != value)
                {
                    _myDiscipline = value;
                    OnPropertyChanged();
                }
            }
        }
        private string _myTimeFull;
        public string MyTimeFull
        {
            get { return _myTimeFull; }
            set
            {
                if (_myTimeFull != value)
                {
                    _myTimeFull = value;
                    OnPropertyChanged();
                }
            }
        }

        private TimeFull _selectedTimeFull { get; set; }
        public TimeFull SelectedTimeFull
        {
            get { return _selectedTimeFull; }
            set
            {
                if (_selectedTimeFull != value)
                {
                    _selectedTimeFull = value;
                    // Do whatever functionality you want...When a selectedItem is changed..
                    // write code here..
                    MyTimeFull = "Selected City : " + _selectedTimeFull.groupName;
                }
            }
        }
        private Discipline _selectedDiscipline { get; set; }
        public Discipline SelectedDiscipline
        {
            get { return _selectedDiscipline; }
            set
            {
                if (_selectedDiscipline != value)
                {
                    _selectedDiscipline = value;
                    // Do whatever functionality you want...When a selectedItem is changed..
                    // write code here..
                    MyDiscipline = "Selected City : " + _selectedDiscipline.Name;
                }
            }
        }
        public List<TimeFull> TimeFullList { get; set; }
        public List<TimeFull> GetTimeFull()
        {
            var cities = new List<TimeFull>()
            {
                new TimeFull(){groupName= "Mumbai"},
                new TimeFull(){groupName= "Bengaluru"},
                new TimeFull(){groupName= "Pune"}
            };

            return cities;
        }
        public List<Discipline> DisciplineList { get; set; }
        public List<Discipline> GetDiscipline()
        {
            var cities = new List<Discipline>()
            {
                new Discipline(){Name= "Mumbai"},
                new Discipline(){Name= "Bengaluru"},
                new Discipline(){Name= "Pune"},
                new Discipline(){Name= "Chennai"},
                new Discipline(){Name= "Ahmedabad"},
                new Discipline(){Name= "Hyderabad"},
                new Discipline(){Name= "Kolkata"}
            };

            return cities;
        }
        private string _selectedDate;
        public string SelectedDate
        {
            get
            {
                return _selectedDate;
            }
            set
            {
                _selectedDate = value;
                RaisePropertyChanged("SelectedDate");
            }
        }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public void RaisePropertyChanged([CallerMemberName] string property = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }


}
